function validateForm() {
	var username = document.forms["login-form"]["username"].value;
	var password = document.forms["login-form"]["password"].value;
	if (username == "" || password == "") {
		alert("Please fill in all fields.");
		return false;
	}
}
