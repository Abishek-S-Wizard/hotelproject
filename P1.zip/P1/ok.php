<html>
  <head>
    <meta charset="utf-8">
    <title>Stats </title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600;700&family=Montserrat:wght@400;500;600;700&display=swap" rel="stylesheet">  

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="lib/animate/animate.css">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />
    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
   

</head>

<body bgcolor="orange+gold" leftmargin="10" topmargin="10" marginwidth="10" marginheight="10">
 
  <!-- Title box -->
 <div class="container-fluid bg-dark px-0">
  <div class="row gx-0">
      <div class="col-lg-3 bg-dark d-none d-lg-block">
          <a href="index.php" class="navbar-brand w-100 h-100 m-0 p-0 d-flex align-items-center justify-content-center">
              <h1 class="m-0 text-primary text-uppercase">KGA HOTEL </h1>
          </a>
      </div>
      <div class="col-lg-9">
          <div class="row gx-0 bg-white d-none d-lg-flex">
              <div class="col-lg-7 px-5 text-start">
                  <div class="h-100 d-inline-flex align-items-center py-2 me-4">
                      <i class="fa fa-envelope text-primary me-2"></i>
                      <p class="mb-0">kgahotel07@gmail.com</p>
                  </div>
                  <div class="h-100 d-inline-flex align-items-center py-2">
                      <i class="fa fa-phone-alt text-primary me-2"></i>
                      <p class="mb-0">+04324 232556</p>
                  </div>
              </div>
              <div class="col-lg-5 px-5 text-end">
                  <div class="d-inline-flex align-items-center py-2">
                      <a class="me-3" href="https://www.facebook.com/chettinadtech.ac.in/"><i class="fab fa-facebook-f"></i></a>
                      <a class="me-3" href=""><i class="fab fa-twitter"></i></a>
                      <a class="me-3" href="https://www.instagram.com/chettinadclg/"><i class="fab fa-instagram"></i></a>
                      <a class="" href="https://www.youtube.com/channel/UCA9C45i5LsOj7SghvS0eHoA"><i class="fab fa-youtube"></i></a>
                  </div>
              </div>
          </div>
          <nav class="navbar navbar-expand-lg bg-dark navbar-dark p-3 p-lg-0">
              <a href="index.php" class="navbar-brand d-block d-lg-none">
                  <h1 class="m-0 text-primary text-uppercase">Hotelier</h1>
              </a>
              <button type="button" class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                  <span class="navbar-toggler-icon"></span>
              </button>
              <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">
                  <div class="navbar-nav mr-auto py-0">
                      <a href="index.php" class="nav-item nav-link active">Home</a>
                      <a href="about.php" class="nav-item nav-link">About</a>
                      <a href="service.php" class="nav-item nav-link">Services</a>
                      <a href="room.php" class="nav-item nav-link">Rooms</a>
                      <a href="ok.php" class="nav-item nav-link">Stats</a>
                      <div class="nav-item dropdown">
                          <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Pages</a>
                          <div class="dropdown-menu rounded-0 m-0">
                              <a href="booking.php" class="dropdown-item">Booking</a>
                              <a href="team.php" class="dropdown-item">Our Team</a>
                             
                          </div>
                      </div>
                      <a href="contact.php" class="nav-item nav-link">Contact</a>
                  </div>
               </div>
          </nav>
      </div>
  </div>
</div>
 <!-- Title box -->
 
 <div class="text-center wow fadeInUp" data-wow-delay="0.1s">
            <h6 class="section-title text-center text-primary text-uppercase">Our Hotel</h6>
            <h1 class="mb-5">Explore Our <span class="text-primary text-uppercase">Stats</span></h1>
</div>
<table width="560" align="center" border="0" cellpadding="5" cellspacing="0">
<tr align="center" valign="top"> 
<td height="59" colspan="2" bgcolor="#FFCCFF"><div align="center"><font color="#FF00CC" size="3" face="Arial, 
Helvetica, sans-serif">-------------------------------------------------------------------------</font><font 
size="3" face="Arial, Helvetica, sans-serif"><br>
<strong><font color="#000000">OUR HOTEL STATS</font></strong><br><font
color="#FF00CC">-------------------------------------------------------------------------</font></font></div></td> </tr>
<tr align="left" valign="top" bgcolor="#FFFFFF">     <td height="22" colspan="2">&nbsp;</td>  </tr>
<tr align="left" valign="top" bgcolor="#FFFFFF"> 
<td height="40" colspan="2"> <p><font color="#00CC00" size="2" face="Arial, Helvetica, sans-serif"><strong><font color="#009900" size="1">DATE: 
05/03/23</font><br>        OUR MISSION : </strong>TO MAKE CUSTOMERS HAPPY<strong><br></strong> </font></p></td></tr>
<tr align="left" valign="top" bgcolor="#CCCCCC"> <td height="5" colspan="2"></td> </tr> <tr align="left" valign="top" bgcolor="#FFFFFF"> 
<td height="10" colspan="2"></td> </tr> <tr align="left" valign="top" bgcolor="#FFFFFF"> 
<td height="20" colspan="2"><font color="#FF00CC" size="2" face="Arial, Helvetica, sans-serif"><strong>Criminal rating:</strong>
0</font></td>  </tr>  <tr align="left" valign="top" bgcolor="#FFFFFF"><td height="10" colspan="2"></td>  </tr>
</font></strong></div></td> </tr> <tr align="left" valign="top" bgcolor="#FFFFFF">  <td height="10" colspan="2"></td> </tr>


<tr align="left" valign="top"><td width="500" height="22" bgcolor="#FFCCFF"><font color="#FF00CC" size="2" face="Arial, Helvetica, sans-serif"><strong>
Members Visited and Stayed</strong></font></td> <td width="500" align="right" valign="middle" bgcolor="#FFCCFF"> <div align="right"><strong><font color="#FF00CC">
1000</font></strong></div></td> </tr> <tr align="left" valign="top" bgcolor="#FFFFFF">  <td height="10" colspan="2"></td> </tr>

<tr align="left" valign="top"><td width="500" height="22" bgcolor="#FFCCFF"><font color="#FF00CC" size="2" face="Arial, Helvetica, sans-serif"><strong>
Foreginer visitor </strong></font></td> <td width="500" align="right" valign="middle" bgcolor="#FFCCFF"> <div align="right"><strong><font color="#FF00CC">
500</font></strong></div></td> </tr> <tr align="left" valign="top" bgcolor="#FFFFFF">  <td height="10" colspan="2"></td> </tr>

<tr align="left" valign="top"><td width="500" height="22" bgcolor="#FFCCFF"><font color="#FF00CC" size="2" face="Arial, Helvetica, sans-serif"><strong>
Number of rooms avaiable</strong></font></td> <td width="500" align="right" valign="middle" bgcolor="#FFCCFF"> <div align="right"><strong><font color="#FF00CC">
800</font></strong></div></td> </tr> <tr align="left" valign="top" bgcolor="#FFFFFF">  <td height="10" colspan="2"></td> </tr>

<tr align="left" valign="top"><td width="500" height="22" bgcolor="#FFCCFF"><font color="#FF00CC" size="2" face="Arial, Helvetica, sans-serif"><strong>
Safehouse visits</strong></font></td> <td width="500" align="right" valign="middle" bgcolor="#FFCCFF"> <div align="right"><strong><font color="#FF00CC">
128</font></strong></div></td> </tr> <tr align="left" valign="top" bgcolor="#FFFFFF">  <td height="10" colspan="2"></td> </tr>

<tr align="left" valign="top"><td width="500" height="22" bgcolor="#FFCCFF"><font color="#FF00CC" size="2" face="Arial, Helvetica, sans-serif"><strong>
Classes based Rooms</strong></font></td> <td width="500" align="right" valign="middle" bgcolor="#FFCCFF"> <div align="right"><strong><font color="#FF00CC">
 4 TYPES</font></strong></div></td> </tr> <tr align="left" valign="top" bgcolor="#FFFFFF">  <td height="10" colspan="2"></td> </tr>

  <tr align="left" valign="top"><td width="500" height="22" bgcolor="#FFCCFF"><font color="#FF00CC" size="2" face="Arial, Helvetica, sans-serif"><strong>
Overall Members Visited</strong></font></td> <td width="500" align="right" valign="middle" bgcolor="#FFCCFF"> <div align="right"><strong><font color="#FF00CC">
  More than 10000</font></strong></div></td> </tr> <tr align="left" valign="top" bgcolor="#FFFFFF">  <td height="10" colspan="2"></td> </tr>

  <tr align="left" valign="top"><td width="500" height="22" bgcolor="#FFCCFF"><font color="#FF00CC" size="2" face="Arial, Helvetica, sans-serif"><strong>
Peoples' whose rated 5 out of 5</strong></font></td> <td width="500" align="right" valign="middle" bgcolor="#FFCCFF"> <div align="right"><strong><font color="#FF00CC">
8000</font></strong></div></td> </tr> <tr align="left" valign="top" bgcolor="#FFFFFF">  <td height="10" colspan="2"></td> </tr>

<tr align="left" valign="top"><td width="500" height="22" bgcolor="#FFCCFF"><font color="#FF00CC" size="2" face="Arial, Helvetica, sans-serif"><strong>
  Peoples' whose rated 4 out of 5</strong></font></td> <td width="500" align="right" valign="middle" bgcolor="#FFCCFF"> <div align="right"><strong><font color="#FF00CC">
1500</font></strong></div></td> </tr> <tr align="left" valign="top" bgcolor="#FFFFFF">  <td height="10" colspan="2"></td> </tr>

<tr align="left" valign="top"><td width="500" height="22" bgcolor="#FFCCFF"><font color="#FF00CC" size="2" face="Arial, Helvetica, sans-serif"><strong>
  Peoples' whose rated 3 out of 5</strong></font></td> <td width="500" align="right" valign="middle" bgcolor="#FFCCFF"> <div align="right"><strong><font color="#FF00CC">
500</font></strong></div></td> </tr> <tr align="left" valign="top" bgcolor="#FFFFFF">  <td height="10" colspan="2"></td> </tr>

<tr align="left" valign="top"><td width="500" height="22" bgcolor="#FFCCFF"><font color="#FF00CC" size="2" face="Arial, Helvetica, sans-serif"><strong>
  Peoples' whose rated 2 out of 5</strong></font></td> <td width="500" align="right" valign="middle" bgcolor="#FFCCFF"> <div align="right"><strong><font color="#FF00CC">
0</font></strong></div></td> </tr> <tr align="left" valign="top" bgcolor="#FFFFFF">  <td height="10" colspan="2"></td> </tr>

<tr align="left" valign="top"><td width="500" height="22" bgcolor="#FFCCFF"><font color="#FF00CC" size="2" face="Arial, Helvetica, sans-serif"><strong>
  Peoples' whose rated 1 out of 5</strong></font></td> <td width="500" align="right" valign="middle" bgcolor="#FFCCFF"> <div align="right"><strong><font color="#FF00CC">
0</font></strong></div></td> </tr> <tr align="left" valign="top" bgcolor="#FFFFFF">  <td height="10" colspan="2"></td> </tr>

<tr align="left" valign="top"><td width="500" height="22" bgcolor="#FFCCFF"><font color="#FF00CC" size="2" face="Arial, Helvetica, sans-serif"><strong>
  Peoples' whose rated 0 out of 5</strong></font></td> <td width="500" align="right" valign="middle" bgcolor="#FFCCFF"> <div align="right"><strong><font color="#FF00CC">
0</font></strong></div></td> </tr> <tr align="left" valign="top" bgcolor="#FFFFFF">  <td height="10" colspan="2"></td> </tr>

<tr align="left" valign="top"><td width="500" height="22" bgcolor="#FFCCFF"><font color="#FF00CC" size="2" face="Arial, Helvetica, sans-serif"><strong>
Number of Floors available</strong></font></td> <td width="500" align="right" valign="middle" bgcolor="#FFCCFF"> <div align="right"><strong><font color="#FF00CC">
28</font></strong></div></td> </tr> <tr align="left" valign="top" bgcolor="#FFFFFF">  <td height="10" colspan="2"></td> </tr>

<tr align="left" valign="top"><td width="500" height="22" bgcolor="#FFCCFF"><font color="#FF00CC" size="2" face="Arial, Helvetica, sans-serif"><strong>
Most Premimum and Costiest Room Price </strong></font></td> <td width="500" align="right" valign="middle" bgcolor="#FFCCFF"> <div align="right"><strong><font color="#FF00CC">
$100000</font></strong></div></td> </tr> <tr align="left" valign="top" bgcolor="#FFFFFF">  <td height="10" colspan="2"></td> </tr>

<tr align="left" valign="top"><td width="500" height="22" bgcolor="#FFCCFF"><font color="#FF00CC" size="2" face="Arial, Helvetica, sans-serif"><strong>
Number of Hospital available </strong></font></td> <td width="500" align="right" valign="middle" bgcolor="#FFCCFF"> <div align="right"><strong><font color="#FF00CC">
8</font></strong></div></td> </tr> <tr align="left" valign="top" bgcolor="#FFFFFF">  <td height="10" colspan="2"></td> </tr>

<tr align="left" valign="top"><td width="500" height="22" bgcolor="#FFCCFF"><font color="#FF00CC" size="2" face="Arial, Helvetica, sans-serif"><strong>
Emergency Number </strong></font></td> <td width="500" align="right" valign="middle" bgcolor="#FFCCFF"> <div align="right"><strong><font color="#FF00CC">
911</font></strong></div></td> </tr> <tr align="left" valign="top" bgcolor="#FFFFFF">  <td height="10" colspan="2"></td> </tr>

<tr align="left" valign="top"><td width="500" height="22" bgcolor="#FFCCFF"><font color="#FF00CC" size="2" face="Arial, Helvetica, sans-serif"><strong>
Security Available for Each Block</strong></font></td> <td width="500" align="right" valign="middle" bgcolor="#FFCCFF"> <div align="right"><strong><font color="#FF00CC">
60</font></strong></div></td> </tr> <tr align="left" valign="top" bgcolor="#FFFFFF">  <td height="10" colspan="2"></td> </tr>

<tr align="left" valign="top"><td width="500" height="22" bgcolor="#FFCCFF"><font color="#FF00CC" size="2" face="Arial, Helvetica, sans-serif"><strong>
Police Available</strong></font></td> <td width="500" align="right" valign="middle" bgcolor="#FFCCFF"> <div align="right"><strong><font color="#FF00CC">
32</font></strong></div></td> </tr> <tr align="left" valign="top" bgcolor="#FFFFFF">  <td height="10" colspan="2"></td> </tr>

<tr align="left" valign="top"><td width="500" height="22" bgcolor="#FFCCFF"><font color="#FF00CC" size="2" face="Arial, Helvetica, sans-serif"><strong>
Number of Movie theatres Available</strong></font></td> <td width="500" align="right" valign="middle" bgcolor="#FFCCFF"> <div align="right"><strong><font color="#FF00CC">
55</font></strong></div></td> </tr> <tr align="left" valign="top" bgcolor="#FFFFFF">  <td height="10" colspan="2"></td> </tr>

<tr align="left" valign="top"><td width="500" height="22" bgcolor="#FFCCFF"><font color="#FF00CC" size="2" face="Arial, Helvetica, sans-serif"><strong>
  Number of Swimming Pool Available</strong></font></td> <td width="500" align="right" valign="middle" bgcolor="#FFCCFF"> <div align="right"><strong><font color="#FF00CC">
100</font></strong></div></td> </tr> <tr align="left" valign="top" bgcolor="#FFFFFF">  <td height="10" colspan="2"></td> </tr>

<tr align="left" valign="top"><td width="500" height="22" bgcolor="#FFCCFF"><font color="#FF00CC" size="2" face="Arial, Helvetica, sans-serif"><strong>
Total Number of Receptions Available</strong></font></td> <td width="500" align="right" valign="middle" bgcolor="#FFCCFF"> <div align="right"><strong><font color="#FF00CC">
20</font></strong></div></td> </tr> <tr align="left" valign="top" bgcolor="#FFFFFF">  <td height="10" colspan="2"></td> </tr>

<tr align="left" valign="top"><td width="500" height="22" bgcolor="#FFCCFF"><font color="#FF00CC" size="2" face="Arial, Helvetica, sans-serif"><strong>
Veg Foods</strong></font></td> <td width="500" align="right" valign="middle" bgcolor="#FFCCFF"> <div align="right"><strong><font color="#FF00CC">
YES Available</font></strong></div></td> </tr> <tr align="left" valign="top" bgcolor="#FFFFFF">  <td height="10" colspan="2"></td> </tr>

<tr align="left" valign="top"><td width="500" height="22" bgcolor="#FFCCFF"><font color="#FF00CC" size="2" face="Arial, Helvetica, sans-serif"><strong>
Non Veg Foods</strong></font></td> <td width="500" align="right" valign="middle" bgcolor="#FFCCFF"> <div align="right"><strong><font color="#FF00CC">
YES Available</font></strong></div></td> </tr> <tr align="left" valign="top" bgcolor="#FFFFFF">  <td height="10" colspan="2"></td> </tr>

<tr align="left" valign="top"><td width="500" height="22" bgcolor="#FFCCFF"><font color="#FF00CC" size="2" face="Arial, Helvetica, sans-serif"><strong>
Number of Different Types of Dishes Available</strong></font></td> <td width="500" align="right" valign="middle" bgcolor="#FFCCFF"> <div align="right"><strong><font color="#FF00CC">
500</font></strong></div></td> </tr> <tr align="left" valign="top" bgcolor="#FFFFFF">  <td height="10" colspan="2"></td> </tr>

<tr align="left" valign="top"><td width="500" height="22" bgcolor="#FFCCFF"><font color="#FF00CC" size="2" face="Arial, Helvetica, sans-serif"><strong>
Mall</strong></font></td> <td width="500" align="right" valign="middle" bgcolor="#FFCCFF"> <div align="right"><strong><font color="#FF00CC">
1</font></strong></div></td> </tr> <tr align="left" valign="top" bgcolor="#FFFFFF">  <td height="10" colspan="2"></td> </tr>

<tr align="left" valign="top"><td width="500" height="22" bgcolor="#FFCCFF"><font color="#FF00CC" size="2" face="Arial, Helvetica, sans-serif"><strong>
Playstations and Games Center Available </strong></font></td> <td width="500" align="right" valign="middle" bgcolor="#FFCCFF"> <div align="right"><strong><font color="#FF00CC">
10</font></strong></div></td> </tr> <tr align="left" valign="top" bgcolor="#FFFFFF">  <td height="10" colspan="2"></td> </tr>

<tr align="left" valign="top"><td width="500" height="22" bgcolor="#FFCCFF"><font color="#FF00CC" size="2" face="Arial, Helvetica, sans-serif"><strong>
Lowest Price Room</strong></font></td> <td width="500" align="right" valign="middle" bgcolor="#FFCCFF"> <div align="right"><strong><font color="#FF00CC">
$200</font></strong></div></td> </tr> <tr align="left" valign="top" bgcolor="#FFFFFF">  <td height="10" colspan="2"></td> </tr>

<tr align="left" valign="top"><td width="500" height="22" bgcolor="#FFCCFF"><font color="#FF00CC" size="2" face="Arial, Helvetica, sans-serif"><strong>
Golf and Cricket ground(small)</strong></font></td> <td width="500" align="right" valign="middle" bgcolor="#FFCCFF"> <div align="right"><strong><font color="#FF00CC">
 YES Available</font></strong></div></td> </tr> <tr align="left" valign="top" bgcolor="#FFFFFF">  <td height="10" colspan="2"></td> </tr>
  

<tr align="left" valign="top"><td width="500" height="22" bgcolor="#FFCCFF"><font color="#FF00CC" size="2" face="Arial, Helvetica, sans-serif"><strong>
Nearest City and Its KMs</strong></font></td> <td width="500" align="right" valign="middle" bgcolor="#FFCCFF"> <div align="right"><strong><font color="#FF00CC">
Chennai   30KMs </font></strong></div></td> </tr> <tr align="left" valign="top" bgcolor="#FFFFFF">  <td height="10" colspan="2"></td> </tr>


<tr align="left" valign="top"><td width="500" height="22" bgcolor="#FFCCFF"><font color="#FF00CC" size="2" face="Arial, Helvetica, sans-serif"><strong>
Boat Ride Available</strong></font></td> <td width="500" align="right" valign="middle" bgcolor="#FFCCFF"> <div align="right"><strong><font color="#FF00CC">
  YES Available</font></strong></div></td> </tr> <tr align="left" valign="top" bgcolor="#FFFFFF">  <td height="10" colspan="2"></td> </tr>

<tr align="left" valign="top"><td width="500" height="22" bgcolor="#FFCCFF"><font color="#FF00CC" size="2" face="Arial, Helvetica, sans-serif"><strong>
Clubs</strong></font></td> <td width="500" align="right" valign="middle" bgcolor="#FFCCFF"> <div align="right"><strong><font color="#FF00CC">
Only one</font></strong></div></td> </tr> <tr align="left" valign="top" bgcolor="#FFFFFF">  <td height="10" colspan="2"></td> </tr>

<tr align="left" valign="top"><td width="500" height="22" bgcolor="#FFCCFF"><font color="#FF00CC" size="2" face="Arial, Helvetica, sans-serif"><strong>
Highest score for Shooter</strong></font></td> <td width="500" align="right" valign="middle" bgcolor="#FFCCFF"> <div align="right"><strong><font color="#FF00CC">
89</font></strong></div></td> </tr> <tr align="left" valign="top" bgcolor="#FFFFFF">  <td height="10" colspan="2"></td> </tr>


<tr align="left" valign="top"><td width="500" height="22" bgcolor="#FFCCFF"><font color="#FF00CC" size="2" face="Arial, Helvetica, sans-serif"><strong>
Minimum Cost Daily  </strong></font></td> <td width="500" align="right" valign="middle" bgcolor="#FFCCFF"> <div align="right"><strong><font color="#FF00CC">
$10000000</font></strong></div></td> </tr> <tr align="left" valign="top" bgcolor="#FFFFFF">  <td height="10" colspan="2"></td> </tr>

<tr align="left" valign="top"><td width="500" height="22" bgcolor="#FFCCFF"><font color="#FF00CC" size="2" face="Arial, Helvetica, sans-serif"><strong>
Overall Employees</strong></font></td> <td width="500" align="right" valign="middle" bgcolor="#FFCCFF"> <div align="right"><strong><font color="#FF00CC">
<tr align="left" valign="top"><td width="500" height="22" bgcolor="#FFCCFF"><font color="#FF00CC" size="2" face="Arial, Helvetica, sans-serif"><strong>
 </strong></font></td><td width="500" align="right" valign="middle" bgcolor="#FFCCFF"> <div align="right"><strong><font color="#FF00CC">
50000</font></strong></div></td> </tr> <tr align="left" valign="top" bgcolor="#FFFFFF">  <td height="10" colspan="2"></td> </tr>

<tr align="left" valign="top"><td width="500" height="22" bgcolor="#FFCCFF"><font color="#FF00CC" size="2" face="Arial, Helvetica, sans-serif"><strong>
Charity Given By Us</strong></font></td> <td width="500" align="right" valign="middle" bgcolor="#FFCCFF"> <div align="right"><strong><font color="#FF00CC">
$1000000</font></strong></div></td> </tr> <tr align="left" valign="top" bgcolor="#FFFFFF">  <td height="10" colspan="2"></td> </tr>

<tr align="left" valign="top"><td width="500" height="22" bgcolor="#FFCCFF"><font color="#FF00CC" size="2" face="Arial, Helvetica, sans-serif"><strong>
Charity Given Goverment and Non Government Organisation</strong></font></td> <td width="500" align="right" valign="middle" bgcolor="#FFCCFF"> <div align="right"><strong><font color="#FF00CC">
$1000000</font></strong></div></td> </tr> <tr align="left" valign="top" bgcolor="#FFFFFF">  <td height="10" colspan="2"></td> </tr>

<tr align="left" valign="top"><td width="500" height="22" bgcolor="#FFCCFF"><font color="#FF00CC" size="2" face="Arial, Helvetica, sans-serif"><strong>
Property Budget</strong></font></td> <td width="500" align="right" valign="middle" bgcolor="#FFCCFF"> <div align="right"><strong><font color="#FF00CC">
$111441500.00</font></strong></div></td> </tr> <tr align="left" valign="top" bgcolor="#FFFFFF">  <td height="10" colspan="2"></td> </tr>

<tr align="left" valign="top"><td width="500" height="22" bgcolor="#FFCCFF"><font color="#FF00CC" size="2" face="Arial, Helvetica, sans-serif"><strong>
Property Destroyed</strong></font></td> <td width="500" align="right" valign="middle" bgcolor="#FFCCFF"> <div align="right"><strong><font color="#FF00CC">
$3234135.00</font></strong></div></td> </tr> <tr align="left" valign="top" bgcolor="#FFFFFF">  <td height="10" colspan="2"></td> </tr>
<tr align="left" valign="top"><td width="500" height="22" bgcolor="#FFCCFF"><font color="#FF00CC" size="2" face="Arial, Helvetica, sans-serif"><strong>
Our Other Properties</strong></font></td> <td width="500" align="right" valign="middle" bgcolor="#FFCCFF"> <div align="right"><strong><font color="#FF00CC">
15 Luxilary Hotels<tr align="left" valign="top"><td width="500" height="22" bgcolor="#FFCCFF"><font color="#FF00CC" size="2" face="Arial, Helvetica, sans-serif"><strong>
 </strong></font></td> <td width="500" align="right" valign="middle" bgcolor="#FFCCFF"> <div align="right"><strong><font color="#FF00CC">
The Malibu<tr align="left" valign="top"><td width="500" height="22" bgcolor="#FFCCFF"><font color="#FF00CC" size="2" face="Arial, Helvetica, sans-serif"><strong>
 </strong></font></td> <td width="500" align="right" valign="middle" bgcolor="#FFCCFF"> <div align="right"><strong><font color="#FF00CC">
Print Works<tr align="left" valign="top"><td width="500" height="22" bgcolor="#FFCCFF"><font color="#FF00CC" size="2" face="Arial, Helvetica, sans-serif"><strong>
 </strong></font></td> <td width="500" align="right" valign="middle" bgcolor="#FFCCFF"> <div align="right"><strong><font color="#FF00CC">
Film Studio<tr align="left" valign="top"><td width="500" height="22" bgcolor="#FFCCFF"><font color="#FF00CC" size="2" face="Arial, Helvetica, sans-serif"><strong>
 </strong></font></td> <td width="500" align="right" valign="middle" bgcolor="#FFCCFF"> <div align="right"><strong><font color="#FF00CC">
Ice Cream Factory<tr align="left" valign="top"><td width="500" height="22" bgcolor="#FFCCFF"><font color="#FF00CC" size="2" face="Arial, Helvetica, sans-serif"><strong>
 </strong></font></td> <td width="500" align="right" valign="middle" bgcolor="#FFCCFF"> <div align="right"><strong><font color="#FF00CC">
Car Showroom<tr align="left" valign="top"><td width="500" height="22" bgcolor="#FFCCFF"><font color="#FF00CC" size="2" face="Arial, Helvetica, sans-serif"><strong>
 </strong></font></td> <td width="500" align="right" valign="middle" bgcolor="#FFCCFF"> <div align="right"><strong><font color="#FF00CC">
Taxi Company<tr align="left" valign="top"><td width="500" height="22" bgcolor="#FFCCFF"><font color="#FF00CC" size="2" face="Arial, Helvetica, sans-serif"><strong>
 </strong></font></td> <td width="500" align="right" valign="middle" bgcolor="#FFCCFF"> <div align="right"><strong><font color="#FF00CC">
Boatyard<tr align="left" valign="top"><td width="500" height="22" bgcolor="#FFCCFF"><font color="#FF00CC" size="2" face="Arial, Helvetica, sans-serif"><strong>
 </strong></font></td> <td width="500" align="right" valign="middle" bgcolor="#FFCCFF"> <div align="right"><strong><font color="#FF00CC">
Pole Position Club<tr align="left" valign="top"><td width="500" height="22" bgcolor="#FFCCFF"><font color="#FF00CC" size="2" face="Arial, Helvetica, sans-serif"><strong>
 </strong></font></td> <td width="500" align="right" valign="middle" bgcolor="#FFCCFF"> <div align="right"><strong><font color="#FF00CC">
3321 Vice Point<tr align="left" valign="top"><td width="500" height="22" bgcolor="#FFCCFF"><font color="#FF00CC" size="2" face="Arial, Helvetica, sans-serif"><strong>
 </strong></font></td> <td width="500" align="right" valign="middle" bgcolor="#FFCCFF"> <div align="right"><strong><font color="#FF00CC">
Links View Apartment<tr align="left" valign="top"><td width="500" height="22" bgcolor="#FFCCFF"><font color="#FF00CC" size="2" face="Arial, Helvetica, sans-serif"><strong>
 </strong></font></td> <td width="500" align="right" valign="middle" bgcolor="#FFCCFF"> <div align="right"><strong><font color="#FF00CC">
El Swanko Casa<tr align="left" valign="top"><td width="500" height="22" bgcolor="#FFCCFF"><font color="#FF00CC" size="2" face="Arial, Helvetica, sans-serif"><strong>
 </strong></font></td> <td width="500" align="right" valign="middle" bgcolor="#FFCCFF"> <div align="right"><strong><font color="#FF00CC">
1102 Washington Street<tr align="left" valign="top"><td width="500" height="22" bgcolor="#FFCCFF"><font color="#FF00CC" size="2" face="Arial, Helvetica, sans-serif"><strong>
 </strong></font></td> <td width="500" align="right" valign="middle" bgcolor="#FFCCFF"> <div align="right"><strong><font color="#FF00CC">
Ocean Heights Apartment<tr align="left" valign="top"><td width="500" height="22" bgcolor="#FFCCFF"><font color="#FF00CC" size="2" face="Arial, Helvetica, sans-serif"><strong>
 </strong></font></td> <td width="500" align="right" valign="middle" bgcolor="#FFCCFF"> <div align="right"><strong><font color="#FF00CC">
Skumole Shack<tr align="left" valign="top"><td width="500" height="22" bgcolor="#FFCCFF"><font color="#FF00CC" size="2" face="Arial, Helvetica, sans-serif"><strong>
 </strong></font></td> <td width="500" align="right" valign="middle" bgcolor="#FFCCFF"> <div align="right"><strong><font color="#FF00CC">
Hyman Condo</font></strong></div></td> </tr> <tr align="left" valign="top" bgcolor="#FFFFFF">  <td height="10" colspan="2"></td> </tr>

<tr align="left" valign="top"><td width="500" height="22" bgcolor="#FFCCFF"><font color="#FF00CC" size="2" face="Arial, Helvetica, sans-serif"><strong>
Highest media attention</strong></font></td> <td width="500" align="right" valign="middle" bgcolor="#FFCCFF"> <div align="right"><strong><font color="#FF00CC">
  Indian Times Today page 12<tr align="left" valign="top"><td width="500" height="22" bgcolor="#FFCCFF"><font color="#FF00CC" size="2" face="Arial, Helvetica, sans-serif"><strong>
 </strong></font></td> <td width="500" align="right" valign="middle" bgcolor="#FFCCFF"> <div align="right"><strong><font color="#FF00CC">
</font></strong></div></td> </tr> <tr align="left" valign="top" bgcolor="#FFFFFF">  <td height="10" colspan="2"></td> </tr>

<tr align="left" valign="top"><td width="500" height="22" bgcolor="#FFCCFF"><font color="#FF00CC" size="2" face="Arial, Helvetica, sans-serif"><strong>
 <center> THANK YOU</center></strong></font></td> <td width="500" align="right" valign="middle" bgcolor="#FFCCFF"> <div align="right"><strong><font color="#FF00CC">
  <center>   VISIT AGAIN</center></font></strong></div></td> </tr> <tr align="left" valign="top" bgcolor="#FFFFFF">  <td height="10" colspan="2"></td> </tr>
  

</table>
<div class="thr">
</div>
<style>
.thr{
   background-color: black;
   width: 100%;
   height: 120px;   

}
</style>

<!-- Last box -->
<div class="container-fluid bg-dark text-light footer wow fadeIn" data-wow-delay="0.1s">
  <div class="c">
      <div class="row g-5">
       
          <div class="col-md-6 col-lg-3">
              <h6 class="section-title text-start text-primary text-uppercase mb-4">Contact</h6>
              <p class="mb-2"><i class="fa fa-map-marker-alt me-3"></i>Big Street, Chennai, India</p>
              <p class="mb-2"><i class="fa fa-phone-alt me-3"></i>+04324 232556</p>
              <p class="mb-2"><i class="fa fa-envelope me-3"></i>kgahotel07@gmail.com</p>
              <div class="d-flex pt-2">
                  <a class="btn btn-outline-light btn-social" href="https://chettinadtech.ac.in/"><i class="fab fa-twitter"></i></a>
                  <a class="btn btn-outline-light btn-social" href="https://www.facebook.com/chettinadtech.ac.in/"><i class="fab fa-facebook-f"></i></a>
                  <a class="btn btn-outline-light btn-social" href="https://www.youtube.com/channel/UCA9C45i5LsOj7SghvS0eHoA"><i class="fab fa-youtube"></i></a>
                  <a class="btn btn-outline-light btn-social" href="https://www.instagram.com/chettinadclg/"><i class="fab fa-instagram"></i></a>
              </div>
          </div>
          
          <div class="col-lg-5 col-md-12">
              <div class="row gy-5 g-4">
                  <div class="col-md-6">
                      <h6 class="section-title text-start text-primary text-uppercase mb-4">Company</h6>
                      <a class="btn btn-link" href="about.php">About Us</a>
                      <a class="btn btn-link" href="contact.php">Contact Us</a>
                      <a class="btn btn-link" href="privacy.php">Privacy Policy</a>
                      <a class="btn btn-link" href="terms and condition.php">Terms & Condition</a>
                      
                  </div>
                  <div class="col-md-6">
                      <h6 class="section-title text-start text-primary text-uppercase mb-4">Services</h6>
                      <a class="btn btn-link" href="food.php">Food & Restaurant</a>
                      <a class="btn btn-link" href="room.php">Hotel & Rooms</a>
                      <a class="btn btn-link" href="sports.php">Sports & Gaming</a>
                      <a class="btn btn-link" href="fitness.php">GYM & Yoga</a>
                  </div>
              </div>
          </div>
      </div>
  </div>

  <div class="container">
      <div class="copyright">
          <div class="row">
              <div class="col-md-6 text-center text-md-start mb-3 mb-md-0">
                  &copy; KGA Hotel, All Right Reserved. 
                   Designed By <a href="https://chettinadtech.ac.in/">Chettinadtech</a>
              </div>
              <div class="col-md-6 text-center text-md-end">
                  <div class="footer-menu">
                      <a href="index.php">Home</a>
                      <a href="">Cookies</a>
                      <a href="contact.php">Help</a>
                      <a href="contact.php">FQAs</a>
                  </div>
              </div>
          </div>
      </div>
  </div>
  <br>
</div>
<!-- Last box -->
</body>
</html>