<?php
session_start();
if ($_SERVER["REQUEST_METHOD"] == "POST") {
	$name = $_POST["name"];
	$email = $_POST["email"];
    $phoneno = $_POST["phoneno"];
	$servername = "localhost";

	$dbname = "database";
	$conn = new mysqli($servername, $username_db, $password_db, $dbname);
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	}
	$sql = "SELECT * FROM users WHERE username='$username' AND password='$password'";
	$result = $conn->query($sql);
	if ($result->num_rows == 1) {
		$_SESSION["username"] = $username;
		header("Location: contact.php");
	} else {
		echo "Try Again.";
	}
	$conn->close();
}
?>
